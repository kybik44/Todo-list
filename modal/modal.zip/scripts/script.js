import toggleModal from './toggle-modal.js';

document.addEventListener('click', function(event){
    const target = event.target;
    if(target.classList.contains('modal')) toggleModal('close');
    if(target.classList.contains('close')) toggleModal('close');
    if(target.classList.contains('ok')) toggleModal('close');
    if(target.classList.contains('add-user')) toggleModal('open');
})